from django.urls import path
from . import views

urlpatterns = [
    path('add/',views.addContact,name='addcontact'),
    path('details/<int:id>',views.details_view,name='detail'),
    path('Update/<int:id>',views.edit_contact,name='edit'),
    path('delete/<int:id>',views.delete_view,name='delete'),

]

