from django import forms
from .models import Contact


class ContactForm(forms.ModelForm):
    class Meta:
        model=Contact
        fields='__all__'


class searchform(forms.Form):
    index=forms.CharField(max_length=255,required=False)