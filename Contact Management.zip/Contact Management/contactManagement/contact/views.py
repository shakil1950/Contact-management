from django.shortcuts import render,redirect,HttpResponse
from .forms import ContactForm,searchform
from .models import Contact
# Create your views here.


def homepage(request):
    
    
    allData=Contact.objects.all()
    context={
        'data':allData,
        
    }
    return render(request,'index.html',context)

def addContact(request):

    form=ContactForm()

    if request.method=='POST':
        form=ContactForm(request.POST)
        if form.is_valid():
            form.save()
            form=ContactForm()
            return redirect('homepage')
        else:
            form=ContactForm()
    
    context={
        'form':form
    }
    return render(request,'add.html',context)

def details_view(request,id):

    data=Contact.objects.get(id=id)
    context={
        'data':data
    }

    return render(request,'details.html',context)

def edit_contact(request,id):

    try:
        data=Contact.objects.get(id=id)
        form=ContactForm(instance=data)
        if request.method=='POST':
            form=ContactForm(request.POST,instance=data)
            if form.is_valid():
                form.save()
                form=ContactForm()
                return redirect('homepage')
            else:
                form=ContactForm(instance=data)
        context={
            'data':data,
            'form':form
        }
        return render(request,'update.html',context)
    except Contact.DoesNotExist:
        HttpResponse('Data Not Found')
        


def delete_view(request,id):
    try:
        data=Contact.objects.get(id=id)
        data.delete()
        return redirect('homepage')
    except Contact.DoesNotExist:
        HttpResponse("Failed due to no data found")

