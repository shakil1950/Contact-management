from django.db import models

# Create your models here.


class Contact(models.Model):
    firstName=models.CharField(max_length=100)
    last_name=models.CharField(max_length=100)
    email=models.EmailField(max_length=250)
    address=models.CharField(max_length=250)
    phone=models.CharField(max_length=11)

    def __str__(self):
        return self.firstName